package com.gzonesoft.kt.cookzzang

class Hello
{
    fun formatMessage(name: String): String = "Hello, $name"
}