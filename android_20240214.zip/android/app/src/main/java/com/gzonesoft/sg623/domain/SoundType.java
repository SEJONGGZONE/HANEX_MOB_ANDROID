package com.gzonesoft.sg623.domain;

public class SoundType {

    public static final String _NEXT = "NEXT";
    public static final String _CLEAR = "CLEAR";


}

