package com.gzonesoft.sg623.domain;

public class UserType {

    public static final String _배송기사 = "배송기사";
    public static final String _관리자 = "관리자";

}

