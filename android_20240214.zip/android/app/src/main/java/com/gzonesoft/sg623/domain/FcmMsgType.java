package com.gzonesoft.sg623.domain;

public class FcmMsgType {

    public static final String _회원가입 = "010";
    public static final String _회원정보수정 = "020";
    public static final String _회원승인 = "030";
    public static final String _회원보류 = "040";
    public static final String _공차등록 = "110";
    public static final String _공차대기 = "120";
    public static final String _협의시작 = "130";
    public static final String _협의완료 = "140";
    public static final String _배차확정 = "150";
    public static final String _배차수정 = "155";
    public static final String _운행시작 = "160";
    public static final String _운행정지 = "170";
    public static final String _재시작 = "180";
    public static final String _운행완료 = "190";
    public static final String _배차취소 = "199";

}

