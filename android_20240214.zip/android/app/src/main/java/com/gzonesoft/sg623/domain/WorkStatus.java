package com.gzonesoft.sg623.domain;

public class WorkStatus {
    public static final String _출근보고 = "100";
    public static final String _퇴근보고 = "200";
    public static final String _배송시작 = "300";
    public static final String _초기화 = "400";
    public static final String _상품이미지삭제 = "500";
    public static final String _납품이미지삭제 = "600";
    public static final String _납품이미지촬영 = "700";
    public static final String _센터출발 = "800";


//    public static final String _로그인 = "100";
//    public static final String _배송순서확정 = "300";
//    public static final String _출하전표출력 = "600";
//    public static final String _출하지출발 = "700";
//    public static final String _인도처도착 = "800";
//    public static final String _인도처출발 = "850";
//    public static final String _완료보고 = "890";
//    public static final String _미도착처리 = "888";
//    public static final String _사고보고 = "999";
}

