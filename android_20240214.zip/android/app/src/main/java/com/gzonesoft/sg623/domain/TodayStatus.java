package com.gzonesoft.sg623.domain;

public class TodayStatus {

    // 출근/퇴근 구분
    public static final String _출근 = "출근";
    public static final String _퇴근 = "퇴근";

}

